import { useEffect, useState } from 'react'

export default function Admin() {
  const [saving, setSaving] = useState(false)
  const [heroTitle, setHeroTitle] = useState('Cut Through the Gadget Noise.')
  const [heroSub, setHeroSub] = useState('Honest, practical, and in-depth reviews that make understanding technology simple.')
  const [heroCta, setHeroCta] = useState('Read Honest Reviews')

  useEffect(() => {
    // TODO: fetch current site content from API
  }, [])

  async function save() {
    setSaving(true)
    try {
      // TODO: call API to save site content
      await new Promise((r) => setTimeout(r, 700))
      alert('Saved (placeholder). Admin backend endpoints will be enabled after DB configuration.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded shadow">
        <h1 className="text-2xl font-semibold">Admin — Tech Core</h1>

        <div className="mt-6 space-y-4">
          <div>
            <label className="block text-sm font-medium">Hero title</label>
            <input value={heroTitle} onChange={(e) => setHeroTitle(e.target.value)} className="mt-1 block w-full border rounded p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium">Hero subheadline</label>
            <textarea value={heroSub} onChange={(e) => setHeroSub(e.target.value)} className="mt-1 block w-full border rounded p-2" rows={4} />
          </div>
          <div>
            <label className="block text-sm font-medium">Hero CTA</label>
            <input value={heroCta} onChange={(e) => setHeroCta(e.target.value)} className="mt-1 block w-full border rounded p-2" />
          </div>

          <div className="pt-4">
            <button onClick={save} disabled={saving} className="bg-indigo-600 text-white px-4 py-2 rounded">
              {saving ? 'Saving…' : 'Save changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
