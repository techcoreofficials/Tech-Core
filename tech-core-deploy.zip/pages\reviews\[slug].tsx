import { prisma } from '../../lib/prisma'
import { useRouter } from 'next/router'

export default function ReviewPage({ review }: { review: any }) {
  const router = useRouter()
  if (router.isFallback) return <div>Loading…</div>
  if (!review) return <div>Not found</div>

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold">{review.title}</h1>
      <p className="text-gray-600 mt-3">{new Date(review.createdAt).toLocaleDateString()}</p>
      <div className="mt-6 prose" dangerouslySetInnerHTML={{ __html: review.content }} />
    </div>
  )
}

export async function getServerSideProps(context: any) {
  const slug = context.params.slug
  const review = await prisma.review.findUnique({ where: { slug } })
  if (!review) return { notFound: true }
  return { props: { review: JSON.parse(JSON.stringify(review)) } }
}
