import Link from 'next/link'
import { prisma } from '../../lib/prisma'

export default function Reviews({ reviews }: { reviews: any[] }) {
  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold">Reviews</h1>
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        {reviews.map((r) => (
          <article key={r.id} className="border rounded p-4">
            <h2 className="font-semibold text-xl">{r.title}</h2>
            <p className="text-gray-600 mt-2">{r.excerpt}</p>
            <div className="mt-4">
              <Link href={`/reviews/${r.slug}`} className="text-indigo-600">Read review</Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

export async function getServerSideProps() {
  const reviews = await prisma.review.findMany({ where: { published: true }, orderBy: { createdAt: 'desc' } })
  return { props: { reviews: JSON.parse(JSON.stringify(reviews)) } }
}
