import Head from 'next/head'

export default function Home() {
  return (
    <div>
      <Head>
        <title>Tech Core</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <main className="min-h-screen bg-white text-gray-900">
        <header className="max-w-6xl mx-auto p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src="/logo.png" alt="Tech Core" className="w-28 h-auto" />
            <span className="font-semibold">Tech Core</span>
          </div>
          <nav className="space-x-4">
            <a href="#reviews" className="text-sm">Reviews</a>
            <a href="#portfolio" className="text-sm">Portfolio</a>
            <a href="#contact" className="text-sm">Contact</a>
          </nav>
        </header>

        <section className="bg-gradient-to-r from-indigo-50 to-pink-50">
          <div className="max-w-6xl mx-auto px-6 py-20 text-center">
            <h1 className="text-4xl md:text-6xl font-extrabold">Cut Through the Gadget Noise.</h1>
            <p className="mt-6 text-lg md:text-2xl text-gray-700">Honest, practical, and in-depth reviews that make understanding technology simple.</p>
            <div className="mt-8">
              <a href="/reviews" className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-md">Read Honest Reviews</a>
            </div>
          </div>
        </section>

        <section id="contact" className="max-w-4xl mx-auto px-6 py-16">
          <h2 className="text-2xl font-semibold">Contact</h2>
          <p className="mt-2 text-gray-600">Send us a message and we'll get back to you.</p>

          <div className="mt-4 text-sm text-gray-700">
            <p><strong>Founder:</strong> Aditya Kushwaha</p>
            <p className="mt-1">YouTube: <a href="https://youtube.com/@aktechnexus?si=QZSWCDnWZk0G7-kP" className="text-indigo-600">aktechnexus</a></p>
            <p className="mt-1">Instagram: <a href="https://www.instagram.com/techcoreofficial?igsi=MWd2YXpkdGM1MmJybw==" className="text-indigo-600">@techcoreofficial</a></p>
            <p className="mt-1">WhatsApp: <a href="https://wa.me/918416841639" className="text-indigo-600">+91 84168 41639</a> • Email: <a href="mailto:officialstechcore@gmail.com" className="text-indigo-600">officialstechcore@gmail.com</a></p>
          </div>

          <form className="mt-6 space-y-4 max-w-xl" method="post" action="/api/contact">
            <div>
              <label className="block text-sm font-medium">Name</label>
              <input name="name" className="mt-1 block w-full border rounded-md p-2" required />
            </div>
            <div>
              <label className="block text-sm font-medium">Email</label>
              <input type="email" name="email" className="mt-1 block w-full border rounded-md p-2" required />
            </div>
            <div>
              <label className="block text-sm font-medium">Message</label>
              <textarea name="message" className="mt-1 block w-full border rounded-md p-2" rows={5} required />
            </div>
            <div>
              <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded-md">Send message</button>
            </div>
          </form>
        </section>

        <footer className="border-t mt-12 py-8">
          <div className="max-w-6xl mx-auto px-6 text-center text-sm text-gray-600">© Tech Core 2026 — Founded by Aditya Kushwaha</div>
        </footer>
      </main>
    </div>
  )
}
