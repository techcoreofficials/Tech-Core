import type { NextApiRequest, NextApiResponse } from 'next'
import bcrypt from 'bcryptjs'
import { prisma } from '../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Warning: this endpoint is for one-time local setup only. Remove after use.
  const email = process.env.ADMIN_INITIAL_EMAIL
  const password = process.env.ADMIN_INITIAL_PASSWORD
  if (!email || !password) return res.status(400).json({ message: 'ADMIN_INITIAL_EMAIL and ADMIN_INITIAL_PASSWORD must be set' })

  const hashed = await bcrypt.hash(password, 10)
  try {
    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) return res.status(200).json({ message: 'Admin already exists' })
    await prisma.user.create({ data: { email, password: hashed, name: 'Admin' } })
    return res.status(201).json({ message: 'Admin created' })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ message: 'Error' })
  }
}
