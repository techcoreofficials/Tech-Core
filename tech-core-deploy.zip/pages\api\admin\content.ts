import type { NextApiRequest, NextApiResponse } from 'next'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '../../../lib/auth'
import { prisma } from '../../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions)
  if (!session) return res.status(401).json({ message: 'Unauthorized' })

  if (req.method === 'GET') {
    const content = await prisma.siteContent.findFirst({ orderBy: { id: 'asc' } })
    return res.json(content)
  }

  if (req.method === 'PUT') {
    const { heroTitle, heroSub, heroCta } = req.body
    const existing = await prisma.siteContent.findFirst()
    if (existing) {
      const updated = await prisma.siteContent.update({ where: { id: existing.id }, data: { heroTitle, heroSub, heroCta } })
      return res.json(updated)
    }
    const created = await prisma.siteContent.create({ data: { heroTitle, heroSub, heroCta } })
    return res.json(created)
  }

  return res.status(405).json({ message: 'Method not allowed' })
}
