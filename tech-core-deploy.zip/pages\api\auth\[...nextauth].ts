import NextAuth from 'next-auth'
import authHandler from '../../../lib/auth'

// NextAuth expects the default export to be the handler
export default authHandler
